window.onload = function() {
    document.getElementsByTagName('span')[0].onclick = function() {
        alert.value = "Alerta";
        alert('Hola Món!');
    };
}